<?php
//******************************************************************************
//* $Id:: uninstall.eldisapi.php 141 2011-12-27 04:59:35Z subhendu       $
//* $Revision:: 141                                                      $ 
//* $Author:: subhendu                                                   $
//* $LastChangedDate:: 2011-12-27 10:29:35 +0530 (Tue, 27 Dec 2011)      $
//******************************************************************************/
defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.installer.adapters.component' );
$db = & JFactory::getDBO();

$query = "SELECT id FROM #__plugins WHERE `element`='eldisapi'";
$db->setQuery($query);
$id = $db->loadResult();

$db->setQuery($query);
$cnt = $db->loadResult();
$query = "UPDATE #__plugins SET `iscore`=0 WHERE id=$id";
$db->setQuery($query);
$db->query();

$installer = new JInstaller;
$result = $installer->uninstall('plugin',$id);
$path = JPATH_PLUGINS.DS.'content'.DS.'eldisapi';
if(file_exists($path)){
@chmod($file, 0777);
rmdir($path);
}

echo 'Thank you for using Eldis Open API';

?>