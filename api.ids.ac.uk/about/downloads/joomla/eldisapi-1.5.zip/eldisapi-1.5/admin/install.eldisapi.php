<?php
//******************************************************************************
//* $Id:: install.eldisapi.php 140 2011-12-26 13:31:24Z subhendu         $
//* $Revision:: 140                                                      $ 
//* $Author:: subhendu                                                   $
//* $LastChangedDate:: 2011-12-26 19:01:24 +0530 (Mon, 26 Dec 2011)      $
//******************************************************************************/
defined('_JEXEC') or die('Restricted access');
jimport('joomla.installer.installer');
$db = & JFactory::getDBO();

$status = new JObject();
$status->plugins = array();
$src = $this->parent->getPath('source');
$plugins = &$this->manifest->getElementByPath('plugins');
if (is_a($plugins, 'JSimpleXMLElement') && count($plugins->children())) {
foreach ($plugins->children() as $plugin) {
$pname = $plugin->attributes('plugin');
$pgroup = $plugin->attributes('group');
$path = $src.DS.'plugins'.DS.$pgroup;
$installer = new JInstaller;
$installer->setOverwrite(true);
$result = $installer->install($path);
$status->plugins[] = array('name' => $pname, 'group' => $pgroup, 'result' => $result);
$query = "SELECT COUNT(*) FROM #__plugins WHERE `folder`='content'";
$db->setQuery($query);
$cnt = $db->loadResult();
$query = "UPDATE #__plugins SET published=0,`ordering`='$cnt', `iscore`=1 WHERE element='{$pname}' AND folder='{$pgroup}'";
$db->setQuery($query);
$db->query();
}}$rows = 0; 
?>