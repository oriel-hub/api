<?php
//******************************************************************************
//* $Id:: multilistcountry.php 107 2011-12-15 11:58:31Z subhendu         $
//* $Revision:: 107                                                      $ 
//* $Author:: subhendu                                                   $
//* $LastChangedDate:: 2011-12-15 17:28:31 +0530 (Thu, 15 Dec 2011)      $
//******************************************************************************/
defined('JPATH_BASE') or die();
$document = &JFactory::getDocument();
$document->addScript( JURI::root(true).'/administrator/components/com_eldisapi/eldis.js');
class JElementMultiListCountry extends JElement
{
	var	$_name = 'MultiListCountry';
	function fetchElement($name, $value, &$node, $control_name)
	{
		$ctrl	= $control_name .'['. $name .']';
		$options = array ();
		$options[] = JHTML::_('select.option', "Countries", JText::_("Countries"));
		$attribs	= ' ';
		if ($v = $node->attributes( 'size' )) {
			$attribs	.= 'size="50"';
		}
		if ($v = $node->attributes( 'class' )) {
			$attribs	.= 'class="'.$v.'"';
		} else {
			$attribs	.= 'class="inputbox"';
		}
		if ($m = $node->attributes( 'multiple' ))
		{
			$attribs	.= ' multiple="multiple"';
			$ctrl		.= '[]';
		}
		
		$attribs	.= 'ondblclick=createFromMultiSelection("paramslist_eldis_country","paramseldis_country")';
		return JHTML::_('select.genericlist', $options, $ctrl, $attribs, 'value', 'text', $value, $control_name.$name );
	}
}