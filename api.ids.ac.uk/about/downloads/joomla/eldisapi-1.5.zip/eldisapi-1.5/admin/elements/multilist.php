<?php
//******************************************************************************
//* $Id:: multilist.php 107 2011-12-15 11:58:31Z subhendu                $
//* $Revision:: 107                                                      $ 
//* $Author:: subhendu                                                   $
//* $LastChangedDate:: 2011-12-15 17:28:31 +0530 (Thu, 15 Dec 2011)      $
//******************************************************************************/
defined('JPATH_BASE') or die();
$document = &JFactory::getDocument();
$document->addScript( JURI::root(true).'/administrator/components/com_eldisapi/eldis.js');
class JElementMultiList extends JElement
{
	var	$_name = 'MultiList';
	function fetchElement($name, $value, &$node, $control_name)
	{
		$ctrl	= $control_name .'['. $name .']';
		$options = array ();
		$options[] = JHTML::_('select.option', "Themes", JText::_("Themes"));
		$attribs	= ' ';
		
		if ($v = $node->attributes( 'size' )) {
			$attribs	.= 'size="50"';
		}
		if ($v = $node->attributes( 'class' )) {
			$attribs	.= 'class="'.$v.'"';
		} else
		{
			$attribs	.= 'class="inputbox"';
		}
		if ($m = $node->attributes( 'multiple' ))
		{
			$attribs	.= ' multiple="multiple"';
			$ctrl		.= '[]';
		}
		$attribs	.= 'ondblclick=createFromMultiSelection("paramslist_eldis_themes","paramseldis_themes")';
		return JHTML::_('select.genericlist', $options, $ctrl, $attribs, 'value', 'text', $value, $control_name.$name );
	}
}