<?php
//******************************************************************************
//* $Id:: button.php 106 2011-12-15 11:58:15Z subhendu                   $
//* $Revision:: 106                                                      $ 
//* $Author:: subhendu                                                   $
//* $LastChangedDate:: 2011-12-15 17:28:15 +0530 (Thu, 15 Dec 2011)      $
//******************************************************************************/
defined('JPATH_BASE') or die();
$document = &JFactory::getDocument();
$document->addScript( JURI::root(true).'/administrator/components/com_eldisapi/eldis.js');
class JElementButton extends JElement
{
	var	$_name = 'button';
	function fetchElement($name, $value, &$node, $control_name)
	{
		$class = $node->attributes( 'class' ) ? $node->attributes( 'class' ) : "text_area";
		$return = '<input type="button"' .
        'id="'   . $control_name . '[' . $name . ']"' .
        'name="params[eldis_guid]"'.
		'onclick="popitup(\'preview.php?search=1\');"'.
		'value="Preview"' .
		'size= "50"'.
        'class="' . $class . '" />'; 
		 return $return;
	}
}