<?php
//******************************************************************************
//* $Id:: multitext.php 138 2011-12-26 12:36:29Z subhendu                $
//* $Revision:: 138                                                      $ 
//* $Author:: subhendu                                                   $
//* $LastChangedDate:: 2011-12-26 18:06:29 +0530 (Mon, 26 Dec 2011)      $
//******************************************************************************/
defined('JPATH_BASE') or die();
$document = &JFactory::getDocument();
$document->addScript( JURI::root(true).'/administrator/components/com_eldisapi/eldis.js');
jimport('joomla.plugin.plugin');
jimport('joomla.filesystem.file');
class JElementMultiText extends JElement
{
	var	$_name = 'multitext';
	function fetchElement($name, $value, &$node, $control_name)
	{
		$plugin = &JPluginHelper::getPlugin('content', 'eldisapi');
		if ($plugin)
		{
			$pluginParams = new JParameter($plugin->params);
			$param = $pluginParams->get('eldis_guid'); 	
			$param_text='';
		}
		else
		{
			$param ='';
			$param_text ='<br/><span style="color:#ff0000;"><small>Please enable plugin</small></span>';
		}

		$class = $node->attributes( 'class' ) ? $node->attributes( 'class' ) : "text_area";
		$return = '<input type="text"' .
		'id="'   . $control_name . '[' . $name . ']"' .
		'name="params[eldis_guid]"'.
		'onblur="validateGUID()"'.
		'value="' . $param . '"' .
		'size= "50"'.
		'class="' . $class . '" />'.$param_text; 
		return $return;
	}
}