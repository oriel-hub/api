var server
var paramseldis_sync_date;
var paramseldis_guid;
var paramseldis_server;
var paramseldis_data_format;
var paramseldis_data_format;
var paramsmycategory;
var paramseldis_sort_value;
var paramseldis_sort_formatsort_desc;
var paramseldis_sort_formatsort_asc;
var paramseldis_sort_formatdefault;
var paramseldis_article_keyword;
var paramseldis_article_publisher;
var paramseldis_article_author;
var paramseldis_skip_days;
var paramseldis_pub_year;
var paramseldis_pub_before;
var paramseldis_pub_after;
var paramseldis_records;
var paramseldis_obj_type;
var paramseldis_country;
var paramseldis_themes;
var isValidGuid;
var themes;
var server;
function checkURL(GUID)
   {
		var xmlhttp;
	    if (window.XMLHttpRequest)
          {
         
     		 xmlhttp=new XMLHttpRequest();
		 
          }
        else
          {
		  
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
        xmlhttp.onreadystatechange=function()
        {
		   
		   if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
				var res=xmlhttp.responseText;
				if(res)
				{
					getCountry(GUID);
					getThemes(GUID);
				    server.disabled=false;
					paramseldis_data_format.disabled=false;
					paramseldis_sort_value.disabled=false;
					paramseldis_obj_type.disabled=false;
					paramseldis_sort_formatsort_desc.disabled=false;
					paramseldis_sort_formatsort_asc.disabled=false;
					paramseldis_sort_formatdefault.disabled=false;
					paramseldis_article_keyword.disabled=false;
					paramseldis_article_publisher.disabled=false;
					paramseldis_article_author.disabled=false;
					paramseldis_skip_days.disabled=false;
					paramseldis_pub_year.disabled=false;
					paramseldis_pub_before.disabled=false;
					paramseldis_pub_after.disabled=false;
					paramseldis_records.disabled=false;
					paramsmycategory.disabled=false;
					object=document.getElementById('paramseldis_country');
					object.disabled=false;
					
				}
				else 
				{
					server.disabled=true;
					paramseldis_data_format.disabled=true;
					paramseldis_sort_value.disabled=true;
					paramseldis_obj_type.disabled=true;
					paramseldis_sort_formatsort_desc.disabled=true;
					paramseldis_sort_formatsort_asc.disabled=true;
					paramseldis_sort_formatdefault.disabled=true;
					paramseldis_article_keyword.disabled=true;
					paramseldis_article_publisher.disabled=true;
					paramseldis_article_author.disabled=true;
					paramseldis_skip_days.disabled=true;
					paramseldis_pub_year.disabled=true;
					paramseldis_pub_before.disabled=true;
					paramseldis_pub_after.disabled=true;
					paramseldis_records.disabled=true;
					paramsmycategory.disabled=true;
					paramseldis_country.disabled=true;
				}
            }
			else
			{
			   
				
			}
          }
        xmlhttp.open("GET","./components/com_eldisapi/elements/validate.php?type="+GUID,true);
        xmlhttp.send();
	}
function validateGUID()
	{
		server = document.getElementById("paramseldis_server");
		paramseldis_data_format= document.getElementById("paramseldis_data_format");
		paramseldis_sort_value= document.getElementById("paramseldis_sort_value");
		paramseldis_obj_type= document.getElementById("paramseldis_sort_value");
		paramseldis_sort_formatsort_desc= document.getElementById("paramseldis_sort_formatsort_desc");
		paramseldis_sort_formatsort_asc= document.getElementById("paramseldis_sort_formatsort_asc");
		paramseldis_sort_formatdefault= document.getElementById("paramseldis_sort_formatdefault");
		paramseldis_article_keyword= document.getElementById("paramseldis_article_keyword");
		paramseldis_article_publisher= document.getElementById("paramseldis_article_publisher");
		paramseldis_article_author= document.getElementById("paramseldis_article_author");
		paramseldis_skip_days= document.getElementById("paramseldis_skip_days");
		paramseldis_pub_year= document.getElementById("paramseldis_pub_year");
		paramseldis_pub_before= document.getElementById("paramseldis_pub_before");
		paramseldis_pub_after= document.getElementById("paramseldis_pub_after");
		paramseldis_records= document.getElementById("paramseldis_records");
		paramseldis_obj_type= document.getElementById("paramseldis_obj_type");
		paramsmycategory= document.getElementById("paramsmycategory");
		paramseldis_country= document.getElementById("paramseldis_country");
		paramseldis_themes= document.getElementById("paramseldis_themes");
		guid = document.getElementById("params[uid]");
		checkURL(guid.value)
	}
function showPreview()
{      
		 var xmlhttp;
	    if (window.XMLHttpRequest)
          {
     		 xmlhttp=new XMLHttpRequest();
		 
          }
        else
          {
		  
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
        xmlhttp.onreadystatechange=function()
        {
		   
		   if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
				var resp=xmlhttp.responseText;
				document.getElementById("plugin-pane").innerHTML=resp;
			}
		}	
		xmlhttp.open("GET","./components/com_eldisapi/elements/priview.php",true);
        xmlhttp.send();
}

function getCountry(GUID)
{
	var xmlhttp;
	    if (window.XMLHttpRequest)
          {
     		 xmlhttp=new XMLHttpRequest();
		 
          }
        else
          {
		  
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
        xmlhttp.onreadystatechange=function()
        {
		   
		   if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
				var resp=xmlhttp.responseText;
				object=document.getElementById('paramslist_eldis_country');
				if(object!=null){
				object.innerHTML=resp;
				object.outerHTML=object.outerHTML;
				} 
			}
		}	
	   if(paramseldis_data_serverEldis.checked==true)
		   {
			  server=paramseldis_data_serverEldis.value;
		   }
			if(paramseldis_data_serverBridge.checked==true)
		   {
			  server=paramseldis_data_serverBridge.value;
		   }
		xmlhttp.open("GET","./components/com_eldisapi/elements/loadcountry.php?type="+GUID+"&server="+server,true);
      xmlhttp.send();
		
}
function getThemes(GUID)
{
		var xmlhttp;
	    if (window.XMLHttpRequest)
          {
     		 xmlhttp=new XMLHttpRequest();
		 
          }
        else
          {
		  
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
        xmlhttp.onreadystatechange=function()
        {
		   
		   if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
				var resp=xmlhttp.responseText;
				object=document.getElementById('paramslist_eldis_themes');
				if(object!=null){
				object.innerHTML=resp;
				object.outerHTML=object.outerHTML;
				} 
			}
		}	
		 if(paramseldis_data_serverEldis.checked==true)
		   {
			  server=paramseldis_data_serverEldis.value;
		   }
			if(paramseldis_data_serverBridge.checked==true)
		   {
			  server=paramseldis_data_serverBridge.value;
		   }
		   
		xmlhttp.open("GET","./components/com_eldisapi/elements/loadthemes.php?type="+GUID+"&server="+server,true);
      xmlhttp.send();
		
}
function init() {
	server = document.getElementById("paramseldis_server");
	paramseldis_data_format= document.getElementById("paramseldis_data_format");
	paramseldis_sort_value= document.getElementById("paramseldis_sort_value");
	paramseldis_obj_type= document.getElementById("paramseldis_sort_value");
	paramseldis_sort_formatsort_desc= document.getElementById("paramseldis_sort_formatsort_desc");
	paramseldis_sort_formatsort_asc= document.getElementById("paramseldis_sort_formatsort_asc");
	paramseldis_sort_formatdefault= document.getElementById("paramseldis_sort_formatdefault");
	paramseldis_article_keyword= document.getElementById("paramseldis_article_keyword");
	paramseldis_article_publisher= document.getElementById("paramseldis_article_publisher");
	paramseldis_article_author= document.getElementById("paramseldis_article_author");
	paramseldis_skip_days= document.getElementById("paramseldis_skip_days");
	paramseldis_pub_year= document.getElementById("paramseldis_pub_year");
	paramseldis_pub_before= document.getElementById("paramseldis_pub_before");
	paramseldis_pub_after= document.getElementById("paramseldis_pub_after");
	paramseldis_records= document.getElementById("paramseldis_records");
	paramseldis_obj_type= document.getElementById("paramseldis_obj_type");
	paramsmycategory= document.getElementById("paramsmycategory");
	paramseldis_country= document.getElementById("paramseldis_country");
	paramseldis_themes= document.getElementById("paramseldis_themes");
	guid = document.getElementById("params[uid]");
	paramseldis_data_serverEldis=document.getElementById("paramseldis_data_servereldis");
	paramseldis_data_serverBridge=document.getElementById("paramseldis_data_serverbridge");
   checkURL(guid.value)
	}
function popitup(url) {
   var formate;
   sort=  document.getElementById("paramseldis_sort_value").value;
   before= document.getElementById("paramseldis_pub_before").value;
   after= document.getElementById("paramseldis_pub_after").value;
   year= document.getElementById("paramseldis_pub_year").value;
   countries=document.getElementById("paramseldis_country").value;
	themes=document.getElementById("paramseldis_themes").value;
	num_records=document.getElementById("paramseldis_records").value;
	guid = document.getElementById("params[uid]").value;
    paramseldis_sort_formatsort_desc= document.getElementById("paramseldis_sort_formatsort_desc");
	paramseldis_sort_formatsort_asc= document.getElementById("paramseldis_sort_formatsort_asc");
	paramseldis_sort_formatdefault= document.getElementById("paramseldis_sort_formatdefault");
   if(paramseldis_data_serverEldis.checked==true)
   {
      server=paramseldis_data_serverEldis.value;
   }
    if(paramseldis_data_serverBridge.checked==true)
   {
      server=paramseldis_data_serverBridge.value;
   }
   if(paramseldis_sort_formatsort_desc.checked==true)
   {
      formate=paramseldis_sort_formatsort_desc.value;
   }
   else if(paramseldis_sort_formatsort_asc.checked==true)
   {
      formate= paramseldis_sort_formatsort_asc.value;
   }
   else
   {
      formate= "default";
   }
 	newwindow=window.open("./components/com_eldisapi/elements/"+url+'&country='+countries+'&themes='+themes+"&num="+num_records+"&GUID="+guid +"&before="+before+"&after="+ after+"&year="+year +"&sort="+sort+"&formate="+formate+"&server="+server ,null,'height=600px,width=600px');
	if (window.focus) {newwindow.focus()}
	return false;
}
window.onload = init;
function createFromMultiSelection(src, dest)
{	
	themes=document.getElementById(src).value;
	if(document.getElementById(dest).value=="")
	{
		document.getElementById(dest).value= themes ;
	}
	else
	{
		document.getElementById(dest).value= document.getElementById(dest).value +","+themes;
	}	
}
