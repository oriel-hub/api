<?php
//******************************************************************************
//* $Id:: eldis_helper.php 107 2011-12-15 11:58:31Z subhendu             $
//* $Revision:: 107                                                      $ 
//* $Author:: subhendu                                                   $
//* $LastChangedDate:: 2011-12-15 17:28:31 +0530 (Thu, 15 Dec 2011)      $
//******************************************************************************/

class EldisHelper
{
   function updatePluginParameters($params)
   {
      $current_date = date("Y-m-d h:i:s");
      $current_date = trim($current_date);
      $params->eldis_sync_date  = trim($current_date);
      $str_plg_params = $this->convertAssocToStr("=",(array)$params);
      
      $plgFolder = "content";
      $plgName = "eldisapi";
      
      $db=&JFactory::getDBO();
      $sql="UPDATE `#__plugins` SET `params` = '".$str_plg_params."' WHERE `#__plugins`.`id` =".$this->getPluginId($plgFolder,$plgName);
      $db->setQuery($sql);
      if($db->query())
         return true;
      else
         return false;
   }
  
  	function convertAssocToStr($glue=",",$assoc_arr = array())
   {
      $str = null;
      foreach($assoc_arr as $key => $val)
      {
         $str .= $key.$glue.$val."\n";
      }
      return $str;
   }
    	
   function getPluginId($folder,$name)
   {
      $db=&JFactory::getDBO();
      $sql='SELECT `id` FROM `#__plugins` WHERE `folder`="'.$db->getEscaped($folder).'" AND `element`="'.$db->getEscaped($name).'"';
      $db->setQuery($sql);
      if(!($plg=$db->loadObject())){
         //JError::raiseError(100,'Fatal: Plugin is not installed or problem in server.');
      }else return (int)$plg->id;
   }
}
?>